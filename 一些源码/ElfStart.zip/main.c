#include "..\inc\swilib.h"
#include "../inc/cfg_items.h"
#include "conf_loader.h"
#include "local_ipc.h"

const char ipc_my_name[]=IPC_TEXTINFO_NAME;
const IPC_REQ my_ipc={
  ipc_my_name,
  ipc_my_name,
  NULL
};

#define TMR_SECOND 216
GBSTMR mytmr;
extern const char name_1[256];
extern const char name_2[256];
extern const char name_3[256];
extern const char name_4[256];
extern const char name_5[256];

extern const int ACTIVE_KEY_1;
extern const int ACTIVE_KEY_2;
extern const int ACTIVE_KEY_3;
extern const int ACTIVE_KEY_4;
extern const int ACTIVE_KEY_5;

extern const int ACTIVE_KEY_STYLE;
extern const int ACTIVE_KEY_STYLE_2;
extern const int ACTIVE_KEY_STYLE_3;
extern const int ACTIVE_KEY_STYLE_4;
extern const int ACTIVE_KEY_STYLE_5;

extern const int ENA_LOCK;

extern const int IDLE_1;
extern const int IDLE_2;
extern const int IDLE_3;
extern const int IDLE_4;
extern const int IDLE_5;

extern void InitConfig();
int my_csm_id;
unsigned int *ErrorNumber;

const char percent_t[]="%t";
int (*old_icsm_onMessage)(CSM_RAM*,GBS_MSG*);
void (*old_icsm_onClose)(CSM_RAM*);
extern void kill_data(void *p, void (*func_p)(void *));

#pragma segment="ELFBEGIN"
void ElfKiller(void)
{
  kill_data(__segment_begin("ELFBEGIN"),(void (*)(void *))mfree_adr());
}

void TimerProc(void)
{
  
  GBS_SendMessage(MMI_CEPID,MSG_IPC,IPC_UPDATE_STAT,&my_ipc);
}

typedef struct
{
  CSM_RAM csm;
  int gui_id;
}MAIN_CSM;   

int start(const char name[128])
{
  WSHDR *ws;
  ws=AllocWS(256);
  str_2ws(ws,name,256);
  ExecuteFile(ws,0,0);
  FreeWS(ws);
  return 1;
}

int mode;

int IsIdle(void)
{ 
  void *icsm=FindCSMbyID(CSM_root()->idle_id); 
  if (IsGuiOnTop(((int*)icsm)[DISPLACE_OF_IDLEGUI_ID/4 ])) 
    return(1); 
  else
  return(0); 
} 

//----------------Keyhook----------------

int mode;

// 0 - no press
// 1 - long press REDBUT
int mode_red;
// 0 - no press
// 1 - long press ENTER_BUTTON
// 2 - disable KEY_UP process
int mode_enter;
int my_keyhook(int submsg, int msg)
{
 //---------------------------- 1 ---------------------------//

  if (submsg==ACTIVE_KEY_1)
    {
      switch(msg)
      {
        case KEY_DOWN:
          if (!ACTIVE_KEY_STYLE)
          {
            if(IDLE_1)
            {
              if(IsIdle())
              {
                start(name_1);
              }
              else
              {
                GBS_SendMessage(MMI_CEPID,KEY_UP,ACTIVE_KEY_1);break;
              }
            }
            else start(name_1);
            return(2);
          }
          else
          {
            if (mode_enter==2)
            {
              GBS_SendMessage(MMI_CEPID,KEY_UP,ACTIVE_KEY_1);
              return (0);
            }
            mode_enter=0;
            return (2);
          }          
        case KEY_UP:
          if (ACTIVE_KEY_STYLE)
          {
            if (mode_enter==0)
            {
              mode_enter=2;
              GBS_SendMessage(MMI_CEPID,KEY_DOWN,ACTIVE_KEY_1);
              return (2);
            }
            if (mode_enter==2)
            {
              mode_enter=0;
              return (0);
            }
            mode_enter=0;
            return (2);
          }          
        case LONG_PRESS:
          if (ACTIVE_KEY_STYLE)
          {
            mode_enter=1;
            if(IDLE_1)
             {
              if(IsIdle())
              {
                start(name_1);
              }
              else  GBS_SendMessage(MMI_CEPID,msg,ACTIVE_KEY_1);
            }
            else start(name_1);
          }
         break;
      }
    }
  
 //---------------------------- 2 ---------------------------//

  if (submsg==ACTIVE_KEY_2)
    {
      switch(msg)
      {
        case KEY_DOWN:
          if (!ACTIVE_KEY_STYLE_2)
          {
           if(IDLE_1)
            {
              if(IsIdle())
              {
                start(name_2);
              }
              else
              {
                GBS_SendMessage(MMI_CEPID,KEY_UP,ACTIVE_KEY_1);break;
              }
            }
            else start(name_2);
            return(2);
          }
          else
          {
            if (mode_enter==2)
            {
              GBS_SendMessage(MMI_CEPID,KEY_UP,ACTIVE_KEY_2);
              return (0);
            }
            mode_enter=0;
            return (2);
          }
          
        case KEY_UP:
          if (ACTIVE_KEY_STYLE_2)
          {
            if (mode_enter==0)
            {
              mode_enter=2;
              GBS_SendMessage(MMI_CEPID,KEY_DOWN,ACTIVE_KEY_2);
              return (2);
            }
            if (mode_enter==2)
            {
              mode_enter=0;
              return (0);
            }
            mode_enter=0;
            return (2);
          }
          
        case LONG_PRESS:
          if (ACTIVE_KEY_STYLE_2)
          {
            mode_enter=1;
            if(IDLE_1)
             {
               if(IsIdle())
               {
                start(name_2);
               }
                else
              {
                GBS_SendMessage(MMI_CEPID,KEY_UP,ACTIVE_KEY_2);
              }
             }
            else start(name_2);
          }
         break;
      }
    }
  
  //---------------------------- 3 ---------------------------//

  if (submsg==ACTIVE_KEY_3)
    {
      switch(msg)
      {
        case KEY_DOWN:
          if (!ACTIVE_KEY_STYLE_3)
          {
          if(IDLE_1)
            {
              if(IsIdle())
              {
                start(name_2);
              }
              else
              {
                GBS_SendMessage(MMI_CEPID,KEY_UP,ACTIVE_KEY_3);break;
              }
            }
            else start(name_3);
            return(2);
          }
          else
          {
            if (mode_enter==2)
            {
              GBS_SendMessage(MMI_CEPID,KEY_UP,ACTIVE_KEY_3);
              return (0);
            }
            mode_enter=0;
            return (2);
          }
          
        case KEY_UP:
          if (ACTIVE_KEY_STYLE_3)
          {
            if (mode_enter==0)
            {
              mode_enter=2;
              GBS_SendMessage(MMI_CEPID,KEY_DOWN,ACTIVE_KEY_3);
              return (2);
            }
            if (mode_enter==2)
            {
              mode_enter=0;
              return (0);
            }
            mode_enter=0;
            return (2);
          }
          
        case LONG_PRESS:
          if (ACTIVE_KEY_STYLE_3)
          {
            mode_enter=1;
        if(IDLE_1)
            {
              if(IsIdle())
              {
                start(name_3);
              }
              else
              {
                GBS_SendMessage(MMI_CEPID,KEY_UP,ACTIVE_KEY_3);
              }
            }
            else start(name_3);
          }
         break;
      }
    }
  
  //---------------------------- 4 ---------------------------//

  if (submsg==ACTIVE_KEY_4)
    {
      switch(msg)
      {
        case KEY_DOWN:
          if (!ACTIVE_KEY_STYLE_4)
          {
       if(IDLE_1)
            {
              if(IsIdle())
              {
                start(name_4);
              }
              else
              {
                GBS_SendMessage(MMI_CEPID,KEY_UP,ACTIVE_KEY_4);break;
              }
            }
            else start(name_4);
            return(2);
          }
          else
          {
            if (mode_enter==2)
            {
              GBS_SendMessage(MMI_CEPID,KEY_UP,ACTIVE_KEY_4);
              return (0);
            }
            mode_enter=0;
            return (2);
          }
          
        case KEY_UP:
          if (ACTIVE_KEY_STYLE_4)
          {
            if (mode_enter==0)
            {
              mode_enter=2;
              GBS_SendMessage(MMI_CEPID,KEY_DOWN,ACTIVE_KEY_4);
              return (2);
            }
            if (mode_enter==2)
            {
              mode_enter=0;
              return (0);
            }
            mode_enter=0;
            return (2);
          }
          
        case LONG_PRESS:
          if (ACTIVE_KEY_STYLE_4)
          {
            mode_enter=1;
         if(IDLE_1)
            {
              if(IsIdle())
              {
                start(name_4);
              }
              else
              {
                GBS_SendMessage(MMI_CEPID,KEY_UP,ACTIVE_KEY_4);
              }
            }
            else start(name_4);
          }
         break;
      }
    }
  
 //---------------------------- 5 ---------------------------//

  if (submsg==ACTIVE_KEY_5)
    {
      switch(msg)
      {
        case KEY_DOWN:
          if (!ACTIVE_KEY_STYLE_5)
          {
            if(IDLE_1)
            {
              if(IsIdle())
              {
                start(name_5);
              }
              else
              {
                GBS_SendMessage(MMI_CEPID,KEY_UP,ACTIVE_KEY_5);break;
              }
            }
            else start(name_5);
            return(2);
          }
          else
          {
            if (mode_enter==2)
            {
              GBS_SendMessage(MMI_CEPID,KEY_UP,ACTIVE_KEY_5);
              return (0);
            }
            mode_enter=0;
            return (2);
          }
          
        case KEY_UP:
          if (ACTIVE_KEY_STYLE_5)
          {
            if (mode_enter==0)
            {
              mode_enter=2;
              GBS_SendMessage(MMI_CEPID,KEY_DOWN,ACTIVE_KEY_5);
              return (2);
            }
            if (mode_enter==2)
            {
              mode_enter=0;
              return (0);
            }
            mode_enter=0;
            return (2);
          }
          
        case LONG_PRESS:
          if (ACTIVE_KEY_STYLE_5)
          {
            mode_enter=1;
         if(IDLE_1)
            {
              if(IsIdle())
              {
                start(name_5);
              }
              else
              {
                GBS_SendMessage(MMI_CEPID,KEY_UP,ACTIVE_KEY_5);
              }
            }
            else start(name_5);
          }
         break;
      }
    }
  return(0);
}
// ----------------------------------------------------------------------------
#define idlegui_id(icsm) (((int *)icsm)[DISPLACE_OF_IDLEGUI_ID/4])

#pragma inline=forced
int toupper(int c)
{
  if ((c>='a')&&(c<='z')) c+='A'-'a';
  return(c);
}
#pragma inline
int strcmp_nocase(const char *s1,const char *s2)
{
  int i;
  int c;
  while(!(i=(c=toupper(*s1++))-toupper(*s2++))) if (!c) break;
  return(i);
}

int maincsm_onmessage(CSM_RAM* data,GBS_MSG* msg)
{
  void *icsm;
  if (msg->msg==MSG_RECONFIGURE_REQ)
  {
    extern const char *successed_config_filename;
    if (strcmp_nocase(successed_config_filename,(char *)msg->data0)==0)
    {
     InitConfig();
      ShowMSG(1,(int)"ElfStart config updated!");
    }
  }
  if (msg->msg==MSG_IPC)
  {
    IPC_REQ *ipc;
    if ((ipc=(IPC_REQ*)msg->data0))
    {
      if (strcmp_nocase(ipc->name_to,ipc_my_name)==0)
      {
        switch (msg->submess)
        {
        case IPC_UPDATE_STAT:
          GBS_StartTimerProc(&mytmr, 10*TMR_SECOND/10, TimerProc);
        }
      }
    }
  }
  icsm=FindCSMbyID(CSM_root()->idle_id);
  if (icsm)
  {
    if (IsGuiOnTop(idlegui_id(icsm))) //���� IdleGui �� ����� �����
    {
      GUI *igui=GetTopGUI();
      if (igui) //� �� ����������
      {
      }
    }
  }
  return(1);

}
static void maincsm_oncreate(CSM_RAM *data)
{
 
  GBS_SendMessage(MMI_CEPID,MSG_IPC,IPC_UPDATE_STAT,&my_ipc);
}

void maincsm_onclose(CSM_RAM *data)
{ 
  RemoveKeybMsgHook((void *)my_keyhook);
  extern void seqkill(void *data, void(*next_in_seq)(CSM_RAM *), void *data_to_kill, void *seqkiller);
  extern void *ELF_BEGIN;
  }
static unsigned short maincsm_name_body[140];
const int minus11=-11;

static const struct
{
  CSM_DESC maincsm;
  WSHDR maincsm_name;
}MAINCSM =
{
  {
  maincsm_onmessage,
  maincsm_oncreate,
#ifdef NEWSGOLD
  0,
  0,
  0,
  0,
#endif
  maincsm_onclose,
  sizeof(CSM_RAM),
  1,
  &minus11
  },
  {
    maincsm_name_body,
    NAMECSM_MAGIC1,
    NAMECSM_MAGIC2,
    0x0,
    139
  }
};


static void UpdateCSMname(void)
{
  wsprintf((WSHDR *)(&MAINCSM.maincsm_name),"ElfStart");
}
// ----------------------------------------------------------------------------


CSM_DESC icsmd;
int main()
{
  CSMROOT *csmr;
  CSM_RAM *save_cmpc;
  CSM_RAM main_csm;
  InitConfig();
  UpdateCSMname();
  LockSched();
  AddKeybMsgHook((void *)my_keyhook);
  csmr=CSM_root();
  save_cmpc=csmr->csm_q->current_msg_processing_csm;
  csmr->csm_q->current_msg_processing_csm=csmr->csm_q->csm.first;
  CreateCSM(&MAINCSM.maincsm,&main_csm,0);
  csmr->csm_q->current_msg_processing_csm=save_cmpc;
  UnlockSched();
//  ShowMSG(1,(int)"Elfstart launch");
  return (0);
}
