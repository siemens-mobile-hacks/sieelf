#define IPC_TEXTINFO_NAME "ElfStart"
#define IPC_UPDATE_STAT 1

