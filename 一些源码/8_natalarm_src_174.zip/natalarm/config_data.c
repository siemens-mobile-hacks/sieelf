#include "D:\ARM_ALL\inc\cfg_items.h"
#include "D:\ARM_ALL\inc\swilib.h"

__root const CFG_HDR cfghdr0={CFG_STR_UTF8,"���� � alarmclock.pd",0,127};
__root const char alarmclock[128]="1:\\system\\alarmclock.pd";

__root const CFG_HDR cfghdr1={CFG_CBOX,"��� ����",0,2};
__root const int type_fon=0;
//__root const CFG_CBOX_ITEM cfgcbox0[2]={"DrawRoundedFrame","DrawImg"};
__root const CFG_CBOX_ITEM cfgcbox0[2]={"DrawCanvas","DrawImg"};

__root const CFG_HDR cfghdr2={CFG_STR_UTF8,"���� � ����",0,127};
__root const char pngfon[128]="0:\\ZBin\\AltMymenu2\\bg.png";


__root const CFG_HDR cfghdr3={CFG_CBOX,"��� DrawCanvas",0,2};
__root const int type_dc=0;
__root const CFG_CBOX_ITEM cfgcbox3[2]={"���.���","������"};


/*__root const CFG_HDR cfghdr3={CFG_CBOX,"��� ������",0,2};
__root const int type_check=1;
__root const CFG_CBOX_ITEM cfgcbox1[2]={"DrawLine","DrawImg"};*/

__root const CFG_HDR cfghdr4={CFG_UINT,"ALARM_ICON",0,6000};
__root const unsigned int  ICON_ALARM=0x003;

//----------------------------��������� ������----------------------------------

__root const CFG_HDR cfghdrm11={CFG_LEVEL,"��������� ������",1,0};

__root const CFG_HDR cfghdr11_1={CFG_COLOR,"����� ����������",0,0};
__root const char color_alarm[4]={0xFF,0xFF,0xFF,0x64};

__root const CFG_HDR cfghdr11_2={CFG_COLOR,"�����",0,0};
__root const char color_time[4]={0xFF,0xFF,0xFF,0x64};

__root const CFG_HDR cfghdr11_3={CFG_COLOR,"���������",0,0};
__root const char color_headline[4]={0xFF,0xFF,0xFF,0x64};

__root const CFG_HDR cfghdr11_4={CFG_COLOR,"����� ���������",0,0};
__root const char color_headline_line[4]={0x00,0x00,0x00,0x64};

__root const CFG_HDR cfghdr11_5={CFG_COLOR,"������",0,0};
__root const char color_snooze[4]={0xFF,0xFF,0xFF,0x64};

__root const CFG_HDR cfghdr11_6={CFG_COLOR,"����� �������",0,0};
__root const char color_snooze_time[4]={0xFF,0xFF,0xFF,0x64};

__root const CFG_HDR cfghdr11_7={CFG_COLOR,"���������",0,0};
__root const char color_active[4]={0xFF,0xFF,0xFF,0x64};

__root const CFG_HDR cfghdr11_8={CFG_COLOR,"���",0,0};
__root const char color_days[4]={0xFF,0xFF,0xFF,0x64};

__root const CFG_HDR cfghdr11_9={CFG_COLOR,"������",0,0};
__root const char color_cursor[4]={0xFF,0xFF,0xFF,0x64};

__root const CFG_HDR cfghdr11_10={CFG_COLOR,"�����",0,0};
__root const char color_soft[4]={0xFF,0xFF,0xFF,0x64};


__root const CFG_HDR cfghdr11_11={CFG_COLOR,"color_line2",0,0};
__root const char color_line2[4]={0xFF,0xFF,0xFF,0x00};

__root const CFG_HDR cfghdr11_12={CFG_COLOR,"color_line3",0,0};
__root const char color_line3[4]={0xFF,0xFF,0xFF,0x00};

__root const CFG_HDR cfghdrm12={CFG_LEVEL,"",0,0};

//----------------------------��������� �������----------------------------------

__root const CFG_HDR cfghdrm13={CFG_LEVEL,"��������� �������",1,0};
__root const CFG_HDR cfghdr13_1={CFG_UINT,"ALARM_TIME_FONT",0,100};
__root const unsigned int ALARM_TIME_FONT=FONT_LARGE;

__root const CFG_HDR cfghdr13_2={CFG_UINT,"HEADLINE_FONT",0,100};
__root const unsigned int HEADLINE_FONT=FONT_MEDIUM;

__root const CFG_HDR cfghdr13_3={CFG_UINT,"TIME_FONT",0,100};
__root const unsigned int TIME_FONT=FONT_MEDIUM;

__root const CFG_HDR cfghdr13_4={CFG_UINT,"SOFTKEY_FONT",0,100};
__root const unsigned int SOFTKEY_FONT=FONT_MEDIUM;

__root const CFG_HDR cfghdr13_5={CFG_UINT,"BODY_FONT",0,100};
__root const unsigned int BODY_FONT=FONT_MEDIUM;

__root const CFG_HDR cfghdr13_6={CFG_UINT,"DAY_FONT",0,100};
__root const unsigned int DAY_FONT=FONT_MEDIUM;

__root const CFG_HDR cfghdrm14={CFG_LEVEL,"",0,0};

//----------------------------��������� ����������������----------------------------------
__root const CFG_HDR cfghdrm15={CFG_LEVEL,"��������� ����������������",1,0};
__root const CFG_HDR cfghdr15_1={CFG_COORDINATES,"ALARM_TIME_Coordinates",0,0};
__root const unsigned int ALARM_TIME_x=105;
__root const unsigned int ALARM_TIME_y=85;

__root const CFG_HDR cfghdr15_2={CFG_COORDINATES,"ALARM_ICON_Coordinates",0,0};
__root const unsigned int ALARM_ICON_x=6;
__root const unsigned int ALARM_ICON_y=55;

__root const CFG_HDR cfghdr15_3={CFG_COORDINATES,"HEAD_Coordinates",0,0};
__root const unsigned int HEAD_x=12;
__root const unsigned int HEAD_y=26;

__root const CFG_HDR cfghdr15_4={CFG_COORDINATES,"TIME_Coordinates",0,0};
__root const unsigned int TIME_x=175;
__root const unsigned int TIME_y=26;

__root const CFG_HDR cfghdr15_5={CFG_COORDINATES,"ALARM_ON_Coordinates",0,0};
__root const unsigned int ALARM_ON_x=35;
__root const unsigned int ALARM_ON_y=155;


__root const CFG_HDR cfghdr15_6={CFG_COORDINATES,"REPEAT_ON_Coordinates",0,0};
__root const unsigned int REPEAT_ON_x=35;
__root const unsigned int REPEAT_ON_y=180;


__root const CFG_HDR cfghdr15_7={CFG_COORDINATES,"REPEAT_TIME_Coordinates",0,0};
__root const unsigned int REPEAT_TIME_x=40;
__root const unsigned int REPEAT_TIME_y=207;

__root const CFG_HDR cfghdr15_8={CFG_COORDINATES,"SOFTKEY_LEFT_Coordinates",0,0};
__root const unsigned int SOFTKEY_x1=10;
__root const unsigned int SOFTKEY_y1=292;

__root const CFG_HDR cfghdr15_9={CFG_COORDINATES,"SOFTKEY_RIGHT_Coordinates",0,0};
__root const unsigned int SOFTKEY_x2=187;
__root const unsigned int SOFTKEY_y2=292;

__root const CFG_HDR cfghdr15_91={CFG_COORDINATES,"DAYS_Coordinates",0,0};
__root const unsigned int DAYS_x=22;
__root const unsigned int DAYS_y=257;

__root const CFG_HDR cfghdr15_92={CFG_UINT,"len_between_days",0,50};
__root const unsigned int len_between_days=28;

__root const CFG_HDR cfghdr15_93={CFG_UINT,"�������� days �����. �box",0,50};
__root const unsigned int smesh=5;

__root const CFG_HDR cfghdr15_94={CFG_UINT,"����. ������� ���. ������ �����",0,50};
__root const unsigned int smesh2=13;

__root const CFG_HDR cfghdr15_95={CFG_UINT,"����. �������� �����. �box",0,50};
__root const unsigned int smesh3=3;

__root const CFG_HDR cfghdr15_96={CFG_UINT,"line2_y",0,320};
__root const unsigned int line2_y=75;

__root const CFG_HDR cfghdr15_97={CFG_UINT,"line3_y",0,320};
__root const unsigned int line3_y=150;

__root const CFG_HDR cfghdrm16={CFG_LEVEL,"",0,0};
//------------------------------------------------------------------------------
