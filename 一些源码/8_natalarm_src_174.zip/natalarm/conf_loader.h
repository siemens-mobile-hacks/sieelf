#ifndef _CONFLOADER_H_
#define _CONFLOADER_H_
void InitConfig();// ������� ����������� ����� ���������� � ���������� ������������
extern const char alarmclock[128];
extern const char pngfon[128];
extern const int type_fon;
extern const int type_dc;
//extern const int type_check;
//��������� ������
extern const char color_soft[4];
extern const char color_cursor[4];
extern const char color_days[4];
extern const char color_alarm[4];
extern const char color_time[4];
extern const char color_headline[4];
extern const char color_headline_line[4];
extern const char color_snooze_time[4];
extern const char color_active[4];
extern const char color_snooze[4];
extern const char color_line2[4];
extern const char color_line3[4];

extern unsigned const int ALARM_TIME_FONT;
extern unsigned const int HEADLINE_FONT;
extern unsigned const int TIME_FONT;
extern unsigned const int BODY_FONT;
extern unsigned const int SOFTKEY_FONT;
extern unsigned const int DAY_FONT;
extern unsigned const int ICON_ALARM;

extern unsigned const int len_between_days;
extern unsigned const int smesh;
extern unsigned const int smesh2;
extern unsigned const int smesh3;

extern unsigned const int ALARM_TIME_x;
extern unsigned const int ALARM_TIME_y;
extern unsigned const int ALARM_ICON_x;
extern unsigned const int ALARM_ICON_y;
extern unsigned const int HEAD_x;
extern unsigned const int HEAD_y;
extern unsigned const int TIME_x;
extern unsigned const int TIME_y;
extern unsigned const int ALARM_ON_x;
extern unsigned const int ALARM_ON_y;
extern unsigned const int REPEAT_ON_x;
extern unsigned const int REPEAT_ON_y;
extern unsigned const int REPEAT_TIME_x;
extern unsigned const int REPEAT_TIME_y;
extern unsigned const int SOFTKEY_y1;
extern unsigned const int SOFTKEY_x1;
extern unsigned const int SOFTKEY_x2;
extern unsigned const int SOFTKEY_y2;
extern unsigned const int DAYS_x;
extern unsigned const int DAYS_y;
extern unsigned const int line2_y;
extern unsigned const int line3_y;
#endif
