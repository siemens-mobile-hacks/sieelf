#include "..\inc\swilib.h"
#include "conf_loader.h"

extern const int DISK0;
extern const int DISK4;
extern const unsigned int DISK0LIM;
extern const unsigned int DISK4LIM;
extern const char MESSAGE[];
extern const unsigned int T;

GBSTMR mytmr;

extern void kill_data(void *p, void (*func_p)(void *));

void ElfKiller(void)
{
  GBS_DelTimer(&mytmr);
  extern void *ELF_BEGIN;
  kill_data(&ELF_BEGIN,(void (*)(void *))mfree_adr());
}

void checkdiskspace(int disk, int limit)
{
  unsigned int er;
  if(GetFreeFlexSpace(disk, &er)/(GetTotalFlexSpace(disk, &er)/100)<limit)
  {
    char *str=malloc(64);
    sprintf(str, MESSAGE, disk);
    ShowMSG(1,(int)str);
    mfree(str);
  }
}

void update()
{
  if(DISK0)
    checkdiskspace(0, DISK0LIM);
  if(DISK4)
    checkdiskspace(4, DISK0LIM);
  GBS_StartTimerProc(&mytmr, (long)T, update);
}


int main(void)
{   
  LockSched();
  InitConfig();
  update();
  UnlockSched();
  return 0;
}
