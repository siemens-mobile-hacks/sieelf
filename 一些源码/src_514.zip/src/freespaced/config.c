#include "..\inc\cfg_items.h"

__root const CFG_HDR cfghdr0={CFG_CHECKBOX,"Disk 0",0,2};
  __root const int DISK0=1;
  
__root const CFG_HDR cfghdr0_1={CFG_UINT,"Limit (%)",0,100};
  __root const unsigned int DISK0LIM=3;
  
__root const CFG_HDR cfghdr1={CFG_CHECKBOX,"Disk 4",0,2};
  __root const int DISK4=0;

__root const CFG_HDR cfghdr1_1={CFG_UINT,"Limit (%)",0,100};
  __root const unsigned int DISK4LIM=5;
  
__root const CFG_HDR cfghdr2={CFG_STR_UTF8,"Message",0,63};
  __root const char MESSAGE[64]="Low disk space\n%d:\\";
    
__root const CFG_HDR cfghdr3={CFG_UINT,"Interval",1000,1000000};
  __root const unsigned int T=10000;