#define NEWSGOLD
#define ELKA

#include "..\inc\cfg_items.h"

#ifdef NEWSGOLD
#define KEYN 26
#else
#define KEYN 24
#endif

__root const CFG_HDR cfghdr0={CFG_CBOX,"Key 1",0,KEYN};
__root const int KEY1 = 11;
__root const CFG_CBOX_ITEM cfgcbox0_1[KEYN]={"1","2","3","4","5","6","7","8","9",
"*","0","#","UP_BUTTON","DOWN_BUTTON","LEFT_BUTTON","RIGHT_BUTTON","ENTER_BUTTON",
"LEFT_SOFT","RIGHT_SOFT","GREEN_BUTTON","RED_BUTTON","VOL_UP_BUTTON","VOL_DOWN_BUTTON",
#ifdef ELKA
"POC_BUTTON",
#else
"INTERNET_BUTTON",
#endif
#ifdef NEWSGOLD
"PLAY_BUTTON","CAMERA_BUTTON"
#endif
};

__root const CFG_HDR cfghdr1={CFG_CBOX,"Key 2",0,KEYN};
__root const int KEY2 = 11;
__root const CFG_CBOX_ITEM cfgcbox1_1[KEYN]={"1","2","3","4","5","6","7","8","9",
"*","0","#","UP_BUTTON","DOWN_BUTTON","LEFT_BUTTON","RIGHT_BUTTON","ENTER_BUTTON",
"LEFT_SOFT","RIGHT_SOFT","GREEN_BUTTON","RED_BUTTON","VOL_UP_BUTTON","VOL_DOWN_BUTTON",
#ifdef ELKA
"POC_BUTTON",
#else
"INTERNET_BUTTON",
#endif
#ifdef NEWSGOLD
"PLAY_BUTTON","CAMERA_BUTTON"
#endif
};

__root const CFG_HDR cfghdr2={CFG_UINT,"Interval",100,2000};
  __root const unsigned int T=100;
