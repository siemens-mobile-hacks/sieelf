#define NEWSGOLD
#define ELKA

#include "..\inc\swilib.h"
#include "conf_loader.h"
#define idlegui_id (((int *)FindCSMbyID(CSM_root()->idle_id))[DISPLACE_OF_IDLEGUI_ID/4])

#ifdef NEWSGOLD
#define KEYN 26
#else
#define KEYN 24
#endif

extern const int KEY1;
extern const int KEY2;
extern const  unsigned int T;

const int code[]={'1', '2', '3', '4', '5', '6', '7', '8', '9', '*', '0', '#', UP_BUTTON, DOWN_BUTTON, LEFT_BUTTON, RIGHT_BUTTON, ENTER_BUTTON, LEFT_SOFT, RIGHT_SOFT, GREEN_BUTTON, RED_BUTTON, VOL_UP_BUTTON, VOL_DOWN_BUTTON,
#ifdef ELKA
POC_BUTTON, 
#else
INTERNET_BUTTON,
#endif
#ifdef NEWSGOLD
PLAY_BUTTON, CAMERA_BUTTON
#endif
};

int k=0;
int press=0;
GBSTMR mytmr;



extern void kill_data(void *p, void (*func_p)(void *));

void ElfKiller(void)
{
  GBS_DelTimer(&mytmr);
  extern void *ELF_BEGIN;
  kill_data(&ELF_BEGIN,(void (*)(void *))mfree_adr());
}



void k0()
{
  k=0;
}


int short_press(int msg)
{
  if (msg==KEY_DOWN) 
    press=1;  
  else if (press)
  {
    press=0;
    if (msg==KEY_UP)
      return 1;
  }
  return 0;
}

void myKbdUnlock()
{
  GBS_SendMessage(MMI_CEPID,LONG_PRESS,'#');
}


int my_keyhook(int submsg, int msg)
{ 
  if (IsGuiOnTop(idlegui_id) || k || press || !IsUnlocked())
    if ((submsg==code[KEY1] && !k)||(submsg==code[KEY2]  && k))
       if(short_press(msg))
      if (k)
      {
        if (IsUnlocked())
        {
          KbdLock();        
        }
        else
        {
          KbdUnlock();
          SetIllumination(0, 1, 100, 200);

        } 
        k=0;
        GBS_SendMessage(MMI_CEPID,KEY_DOWN,RED_BUTTON);
      }
      else
      {
        k=1;
        GBS_StartTimerProc(&mytmr, T, k0);
      }
  return 0;
}

int main(void)
{
  LockSched();
  InitConfig();
  AddKeybMsgHook((void *)my_keyhook);
  UnlockSched();
  return 0;
}
