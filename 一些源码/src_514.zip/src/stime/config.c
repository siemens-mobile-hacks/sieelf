#include "..\inc\cfg_items.h"

__root const CFG_HDR cfghdr0={CFG_CBOX,"Language",0,2};
__root const int LANG = 0;
__root const CFG_CBOX_ITEM cfgcbox0_1[2]={"Russian","English"};


__root const CFG_HDR cfghdr1={CFG_CBOX,"Time format",0,2};
__root const int FORMAT = 0;
__root const CFG_CBOX_ITEM cfgcbox1_1[2]={"24h","12h"};
