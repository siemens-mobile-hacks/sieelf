#include "..\inc\swilib.h"
#define SCREENSIZE ScreenH()*ScreenW()
#define HSIZE YDISP*ScreenW()

extern void kill_data(void *p, void (*func_p)(void *));

void ElfKiller(void)
{
  extern void *ELF_BEGIN;
  kill_data(&ELF_BEGIN,(void (*)(void *))mfree_adr());
}


DrwImg(IMGHDR *img, int x, int y, char *pen, char *brush)
{
  RECT rc;
  DRWOBJ drwobj;
  StoreXYWHtoRECT(&rc,x,y,img->w,img->h);
  SetPropTo_Obj5(&drwobj,&rc,0,img);
  SetColor(&drwobj,pen,brush);
  DrawObject(&drwobj);
}


int main(void)
{   
  LockSched();
  short *p=malloc((SCREENSIZE-HSIZE)*sizeof(short)), *pp=RamScreenBuffer();
  IMGHDR img={ScreenW(),(ScreenH()-YDISP),8,(char *)p};
  pp+=SCREENSIZE;
  for(int i=0;i<SCREENSIZE-HSIZE;i++,p++,pp--)
    *p=*pp;
  DrwImg(&img, 0, YDISP, GetPaletteAdrByColorIndex(0),GetPaletteAdrByColorIndex(2));
  mfree(img.bitmap);
  UnlockSched();
  return 0;
}
