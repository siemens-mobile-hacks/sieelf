#include "..\inc\swilib.h"

extern void kill_data(void *p, void (*func_p)(void *));

void ElfKiller(void)
{
  extern void *ELF_BEGIN;
  kill_data(&ELF_BEGIN,(void (*)(void *))mfree_adr());
}

int main(char *exename, char *fname)
{   
  char fl[]="x:\\bvtmp.htm",
  str1[]="<html>\n<body>\n",
  str2[]="</body>\n</html>",
  *str3;
  int handle;
  unsigned int err;
  fl[0]=exename[0];
  handle=fopen(fl,A_TXT+A_WriteOnly+A_Create,P_WRITE,&err);
  if(handle!=-1)
  {
    fwrite(handle,str1,strlen(str1),&err);
    char dir[]="x:\\Pictures";
    dir[0]=exename[0];
    static DIR_ENTRY de; 
    char path[128]; strcpy(path,dir);
    char *ptr=path+strlen(path)+1;
    strcat(path,"\\*.jpg"); if (FindFirstFile(&de,path,&err)){
      do
      { 
        strcpy(ptr,de.file_name);
        char *p=path,*name;
        while(p=strchr(p,'\\'))
          *p='/';
        name=strrchr(path,'/')+1;
        str3=malloc(strlen(path)+strlen(name)+100);
        sprintf(str3,
                "<a href=\"file://%s\">%s</a><br>\n",
                path, name);
        fwrite(handle,str3,strlen(str3),&err);
        mfree(str3);
      }
      while(FindNextFile(&de,&err));
    }FindClose(&de,&err);
    fwrite(handle,str2,strlen(str2),&err);
  }
  fclose(handle, &err); 
  WSHDR *ws=AllocWS(256);
  str_2ws(ws,fl,strlen(fl)+1);
  ExecuteFile(ws,0,0); FreeWS(ws);
  UnlockSched();
}


