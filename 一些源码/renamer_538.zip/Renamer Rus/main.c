#include "..\inc\swilib.h"
#include "conf_loader.h"
void start_vibra(void);
void stop_vibra(void);
GBSTMR tmr_vibra;

extern const char Dir[128];
extern const char Symbol[128];
extern const char Text[128];
extern const char AftText[128];
extern const char PreFname[128];
extern const char Fname[128];

extern const int MSG;
extern const int WAV;
extern const int VIBRA;
unsigned int *err,m=0;
char RenDir[128];
unsigned int vibra_countf;
extern const unsigned int vibra_count;
extern const unsigned int vibra_power;
extern const unsigned int volume;

void Play(const char *fname)
{if (!IsCalling()&&!RamMediaIsPlaying())
  {FSTATS fstats;
    unsigned int err;
    if (GetFileStats(fname,&fstats,&err)!=-1)
     {PLAYFILE_OPT _sfo1;
      WSHDR* sndPath=AllocWS(128);
      WSHDR* sndFName=AllocWS(128);
      char s[128];
      const char *p=strrchr(fname,'\\')+1;
      str_2ws(sndFName,p,128);
      strncpy(s,fname,p-fname);
      s[p-fname]='\0';
      str_2ws(sndPath,s,128);    
      zeromem(&_sfo1,sizeof(PLAYFILE_OPT));
      _sfo1.repeat_num=1;
      _sfo1.time_between_play=0;
      _sfo1.play_first=0;
      _sfo1.volume=volume;
#ifdef NEWSGOLD
      _sfo1.unk6=1;
      _sfo1.unk7=1;
      _sfo1.unk9=2;
      /*PLAY_ID=*/PlayFile(0x10, sndPath, sndFName, MMI_CEPID, MSG_PLAYFILE_REPORT, &_sfo1);
#else
#ifdef X75
      _sfo1.unk4=0x80000000;
      _sfo1.unk5=1;
      /*PLAY_ID=*/PlayFile(0xC, sndPath, sndFName, 0,MMI_CEPID, MSG_PLAYFILE_REPORT, &_sfo1);
#else
      _sfo1.unk5=1;
      /*PLAY_ID=*/PlayFile(0xC, sndPath, sndFName, MMI_CEPID, MSG_PLAYFILE_REPORT, &_sfo1);
#endif
#endif
      FreeWS(sndPath);
      FreeWS(sndFName);}}}

void start_vibra()
{stop_vibra();
  if(!IsCalling())
  {SetVibration(vibra_power);
   GBS_StartTimerProc(&tmr_vibra,216>>1,stop_vibra);
 }}
void stop_vibra()
{SetVibration(0);
 if(--vibra_countf) GBS_StartTimerProc(&tmr_vibra,216>>1,start_vibra); 
}

void main()
{InitConfig();
 strcpy(RenDir,Dir);
 strcat((char*)Dir,"\\");
 strcat((char*)Symbol,"\\");
 strcat(RenDir,Symbol);
 vibra_countf=vibra_count;
 
 if(isdir(Dir,err)&&m==0)
 {if(WAV) Play(PreFname);
  if(MSG) ShowMSG(1,(int)Text); 
  if(VIBRA) start_vibra();
  fmove(Dir,RenDir,err);
  m=1;}
 if(isdir(RenDir,err)&&m==0)
 {if(WAV) Play(Fname);
  if(MSG) ShowMSG(1,(int)AftText);
  if(VIBRA) start_vibra();
  fmove(RenDir,Dir,err);
 } GBS_DelTimer(&tmr_vibra);
}
