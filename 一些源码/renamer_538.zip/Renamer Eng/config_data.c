#include "..\inc\cfg_items.h"

__root const CFG_HDR cfghdr0={CFG_STR_UTF8,"Directory",0,127};
__root const char Dir[128]="0:\\Hello";

__root const CFG_HDR cfghdr1={CFG_STR_UTF8,"Symbol",0,127};
__root const char Symbol[128]="_";

//---------------------------------------------------
__root const CFG_HDR cfghdr2={CFG_LEVEL,"Text",1,0};

__root const CFG_HDR cfghdr4_1={CFG_CBOX,"Enable text message?",0,2};
__root const int MSG=1;
__root const CFG_CBOX_ITEM cfgcbox0[2]={"No","Yes"};

__root const CFG_HDR cfghdr4_2={CFG_STR_UTF8,"Text before",0,127};
__root const char Text[128]="Renamed!";

__root const CFG_HDR cfghdr4_3={CFG_STR_UTF8,"Text after",0,127};
__root const char AftText[128]="UnRenamed!";

__root const CFG_HDR cfghdr3={CFG_LEVEL,"",0,0};

//-----------------------------------------------------
__root const CFG_HDR cfghdr5={CFG_LEVEL,"Melody",1,0};

__root const CFG_HDR cfghdr7_1={CFG_CBOX,"Play melody?",0,2};
__root const int WAV=1;
__root const CFG_CBOX_ITEM cfgcbox8[2]={"No","Yes"};

__root const CFG_HDR cfghdr7_2={CFG_STR_UTF8,"Melody before",0,127};
__root const char PreFname[128]="4:\\ZBin\\Snd\\Ranamer\\Rename.wav";

__root const CFG_HDR cfghdr7_4={CFG_STR_UTF8,"Melody after",0,127};
__root const char Fname[128]="4:\\ZBin\\Snd\\Ranamer\\Rename.wav";

__root const CFG_HDR cfghdr7_5={CFG_UINT,"Volume",0,6};
__root const unsigned int volume=4;

__root const CFG_HDR cfghdr6={CFG_LEVEL,"",0,0};

//-----------------------------------------------------
__root const CFG_HDR cfghdr_19={CFG_LEVEL,"Vibra",1,0};

__root const CFG_HDR cfghdr21_1={CFG_CBOX,"Enable vibra?",0,2};
__root const int VIBRA=1;
__root const CFG_CBOX_ITEM cfgcbox10[2]={"���","��"};

__root const CFG_HDR cfghdr21_2 = {CFG_UINT, "Amount", 0, 10};
__root const unsigned int vibra_count=3;

__root const CFG_HDR cfghdr21_3 = {CFG_UINT, "Power", 0, 100};
__root const unsigned int vibra_power=50;

__root const CFG_HDR cfghdr_20={CFG_LEVEL,"",0,0};



