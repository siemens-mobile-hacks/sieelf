#ifndef _BOOKMARKS_H_
  #define _BOOKMARKS_H_
//#include "main.h"
int curpos;
#endif
