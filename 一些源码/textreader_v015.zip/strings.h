unsigned int char8to16(int c, int type);
unsigned int char16to8(unsigned int c);
void ascii2ws(WSHDR *ws, const char *s);
void koi2ws(WSHDR *ws, const char *s);
void win1250_2ws(WSHDR *ws, const char *s);
void win1251_2ws(WSHDR *ws, const char *s);


