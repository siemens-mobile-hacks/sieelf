#ifndef _FILE_WORKS_H_
#define _FILE_WORKS_H_

char * getSymbolicPath(const char * cFileName);
int ballet_fexists(const char * cFileName);
int make_dirs(const char * path);

#endif /* _FILE_WORKS_H_ */
