//��� ���������� � ��������, �������
struct
{
 char name[NUM_RECORD+1][15];
 int points[NUM_RECORD+1];
}record;//� ��������)))
void parserecord(int mode)
{
if(mode==0)
{
for(int i=0;i<NUM_RECORD;i++)
{
  strcpy(record.name[i],lang[36]);
  record.points[i]=0;
}
}
else
if(mode==1)
{
for(int i=0;i<NUM_RECORD;i++)
{
  if(user.lifetime>record.points[i]||cpu.lifetime>record.points[i])
  {
    for(int a=NUM_RECORD;a>i;a--)
    {
    strcpy(record.name[a],record.name[a-1]);
    record.points[a]=record.points[a-1];
    }
    if(user.lifetime>record.points[i])
    {
    strcpy(record.name[i],name);
    record.points[i]=user.lifetime;
    }
    if(cpu.lifetime>record.points[i])
    {
    strcpy(record.name[i],"Cpu");
    record.points[i]=cpu.lifetime;
    }
    return;
  }
}
}
user.lifetime=cpu.lifetime=0;
}
void savedata(int mod)
{
parserecord(mod);
folders=malloc(sizeof(folder)+strlen("data.sys")+1);
strcpy(folders,folder);
strcat(folders,"data.sys");
int f = fopen(folders,A_WriteOnly+A_BIN+A_Create+A_Truncate,P_WRITE,&err);
if(f!=-1)
{
fwrite(f,&langenru,sizeof(langenru),&err);
fwrite(f,&saveload,sizeof(saveload),&err);
fwrite(f,&mode,sizeof(mode),&err);
fwrite(f,&on_off_sound,sizeof(on_off_sound),&err);
fwrite(f,&diff,sizeof(diff),&err);
fwrite(f,&speed_game,sizeof(diff),&err);
fwrite(f,&lives,sizeof(lives),&err);
fwrite(f,&def_vol,sizeof(def_vol),&err);
fwrite(f,&vibra,sizeof(vibra),&err);
fwrite(f,&record,sizeof(record),&err);
fclose(f,&err);
}
mfree(folders);
}

void loadNastr()//��� ��������
{
folders=malloc(sizeof(folder)+strlen("data.sys")+1);
strcpy(folders,folder);
strcat(folders,"data.sys");
int f = fopen(folders,A_ReadOnly+A_BIN,P_READ,&err);
if(f!=-1)
{
fread(f,&langenru,sizeof(langenru),&err);
fread(f,&saveload,sizeof(saveload),&err);
fread(f,&mode,sizeof(mode),&err);
fread(f,&on_off_sound,sizeof(on_off_sound),&err);
fread(f,&diff,sizeof(diff),&err);
fread(f,&speed_game,sizeof(diff),&err);
fread(f,&lives,sizeof(lives),&err);
fread(f,&def_vol,sizeof(def_vol),&err);
fread(f,&vibra,sizeof(vibra),&err);
fread(f,&record,sizeof(record),&err);
fclose(f,&err);
lgpInitLangPack();
T_Load_IMG();
}
else
{
isload=1;
load_lang();
}
mfree(folders);
}

void saveSettings()//��������� ��������
{
folders=malloc(sizeof(folder)+strlen("save\\savedata.pp")+1);
strcpy(folders,folder);
strcat(folders,"save\\savedata.pp");
int f = fopen(folders,A_WriteOnly+A_BIN+A_Create+A_Truncate,P_WRITE,&err);
if(f!=-1)
{
fwrite(f,&user,sizeof(Mytype),&err);
fwrite(f,&cpu,sizeof(Mytype),&err);
fwrite(f,&ball,sizeof(Mytype),&err);
fwrite(f,&mode,sizeof(mode),&err);
fwrite(f,&on_off_sound,sizeof(on_off_sound),&err);
fwrite(f,&AI_line,sizeof(AI_line),&err);
fwrite(f,&Time,sizeof(Time),&err);
fclose(f,&err);
}
mfree(folders);
RedrawScreen();
}

void loadSettings()//��������� ��������
{
folders=malloc(sizeof(folder)+strlen("save\\savedata.pp")+1);
strcpy(folders,folder);
strcat(folders,"save\\savedata.pp");
int f = fopen(folders,A_ReadOnly+A_BIN,P_READ,&err);
if(f!=-1)
{
fread(f,&user,sizeof(Mytype),&err);
fread(f,&cpu,sizeof(Mytype),&err);
fread(f,&ball,sizeof(Mytype),&err);
fread(f,&mode,sizeof(mode),&err);
fread(f,&on_off_sound,sizeof(on_off_sound),&err);
fread(f,&AI_line,sizeof(AI_line),&err);
fread(f,&Time,sizeof(Time),&err);
fclose(f,&err);
}
mfree(folders);
RedrawScreen();
}
