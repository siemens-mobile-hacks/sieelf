void png(int w)
{
  clear++;
  switch(w)
  {
  case 4:pics[0]=CreateIMGHDRFromPngFile(images[4], 2);break;//user1
  case 3:pics[1]=CreateIMGHDRFromPngFile(images[3], 2);break;//user2
  case 5:pics[2]=CreateIMGHDRFromPngFile(images[5], 2);break;//ball
  case 1:pics[3]=CreateIMGHDRFromPngFile(images[1], 2);break;//cur
  case 0:pics[4]=CreateIMGHDRFromPngFile(images[0], 2);break;//logo
  case 2:pics[5]=CreateIMGHDRFromPngFile(images[2], 2);break;//fon
  }
}
void T_Load_IMG()//�������� � ������
{
  loading(img_count);
  img_count++;
  if(img_count<8){GBS_StartTimerProc(&tmr, timer_speed, T_Load_IMG);}
  if(img_count==8){GBS_DelTimer(&tmr);}
}

void DrwImg(IMGHDR *img, int x, int y)
{
  RECT rc;
  DRWOBJ drwobj;
  StoreXYWHtoRECT(&rc,x,y,img->w,img->h);
  SetPropTo_Obj5(&drwobj,&rc,0,img);
  DrawObject(&drwobj);
}

void Game()
{

  if(StrToInt((char*)GetCPUClock(),NULL)<208)
  {
  SetCpuClockTempHi(2);
  }
#ifdef DBG
  TTime time;
  sfps++;
  GetDateTime(NULL,&time);
  if(lastsec!=time.sec)
  {
    lastsec = time.sec;
    fps = sfps;
    sfps = 0;
  }
#endif
Time.mymsec++;
if(Time.mymsec>=(TMR_SECOND/timer_speed-15)){Time.mymsec=0;Time.sec++;}
if(Time.sec>=60){Time.min++;Time.sec=0;}
if(Time.min==60){Time.hour++;Time.min=0;}
if(Time.hour>=1){sprintf(Time.str,"%d � %d � %d �",Time.hour,Time.min,Time.sec);}
else
if(Time.min>=1){sprintf(Time.str,"%d � %d �",Time.min,Time.sec);}
else{sprintf(Time.str,"%d �",Time.sec);}
DrwImg(pics[5],0,0);
move_ball();
DrawLine(1,((max_height-cpu.height-user.height-cpu.y)/2)+cpu.y,max_width-1,((max_height-cpu.height-user.height-cpu.y)/2)+cpu.y,0,linecol2);
DrawRectangle(1,nimg*22,max_width-1,max_height-2,0,linecol,NULL);
DrwImg(pics[0],user.x,user.y);
DrwImg(pics[2],ball.x,ball.y);
DrwImg(pics[1],cpu.x,cpu.y);
if (running==1){move_block();
GBS_StartTimerProc(&tmr,timer_speed,Game);}
}
void RedrawScreen()//���������� ������� ����������� �������� ����
{
WSHDR *ws_menu = AllocWS(32);
if(status!=game){DrwImg(pics[4],0,0);}
else{Game();}
switch(status)
{
case menu:
 {
DrwImg(pics[3],cur_x,cur_y);

switch(game_new_cont)
{
case 1:wsprintf(ws_menu,perc_t,lang[1]);break;
case 2:wsprintf(ws_menu,perc_t,lang[2]);break;
case 3:wsprintf(ws_menu,perc_t,lang[3]);break;
}
DrawString(ws_menu,0,main_y,max_width,max_height,FONT,2,GetPaletteAdrByColorIndex(2),GetPaletteAdrByColorIndex(23));
switch(saveload)
{
case 1:wsprintf(ws_menu,perc_t,lang[4]);break; 
case 2:wsprintf(ws_menu,perc_t,lang[5]);break;
}
DrawString(ws_menu,0,main_y+nimg*40,max_width,max_height,FONT,2,GetPaletteAdrByColorIndex(2),GetPaletteAdrByColorIndex(23));
switch(mode)
{
case 1: wsprintf(ws_menu,perc_t,lang[6]); break; 
case 0: wsprintf(ws_menu,perc_t,lang[8]); break;
}
DrawString(ws_menu,0,main_y+nimg*80,max_width,max_height,FONT,2,GetPaletteAdrByColorIndex(2),GetPaletteAdrByColorIndex(23));

wsprintf(ws_menu,perc_t,lang[9]);
DrawString(ws_menu,0,main_y+nimg*120,max_width,max_height,FONT,2,GetPaletteAdrByColorIndex(2),GetPaletteAdrByColorIndex(23));

wsprintf(ws_menu,perc_t,lang[10]);
DrawString(ws_menu,0,main_y+nimg*160,max_width,max_height,FONT,2,GetPaletteAdrByColorIndex(2),GetPaletteAdrByColorIndex(23));

wsprintf(ws_menu,perc_t,lang[11]);
DrawString(ws_menu,0,main_y+nimg*200,max_width,max_height,FONT,2,GetPaletteAdrByColorIndex(2),GetPaletteAdrByColorIndex(23));
}
break;
case settings:
{
DrwImg(pics[3],cur_x,cur_ys1);
wsprintf(ws_menu,perc_t,lang[12]);
DrawString(ws_menu,0,set_y,max_width,max_height,FONT,2,GetPaletteAdrByColorIndex(2),GetPaletteAdrByColorIndex(23));
wsprintf(ws_menu,perc_t,lang[26]);
DrawString(ws_menu,0,set_y+nimg*60,max_width,max_height,FONT,2,GetPaletteAdrByColorIndex(2),GetPaletteAdrByColorIndex(23));
}
break;
case settings_igra:
{
DrwImg(pics[3],cur_x,cur_ys);
wsprintf(ws_menu,perc_t,lang[15]);
DrawString(ws_menu,0,seti_y,max_width,max_height,FONT,2,GetPaletteAdrByColorIndex(3),GetPaletteAdrByColorIndex(23));
switch(diff)
{
case 0:wsprintf(ws_menu,perc_t,lang[16]);break;
case 1:wsprintf(ws_menu,perc_t,lang[17]);break;
case 2:wsprintf(ws_menu,perc_t,lang[18]);break;
}
DrawString(ws_menu,0,seti_y+nimg*30,max_width,max_height,FONT,2,GetPaletteAdrByColorIndex(2),GetPaletteAdrByColorIndex(23));

wsprintf(ws_menu,perc_t,lang[19]);
DrawString(ws_menu,0,seti_y+nimg*60,max_width,max_height,FONT,2,GetPaletteAdrByColorIndex(3),GetPaletteAdrByColorIndex(23));
switch(speed_game)
{
case 0:wsprintf(ws_menu,perc_t,lang[20]);break;
case 1:wsprintf(ws_menu,perc_t,lang[21]);break;
case 2:wsprintf(ws_menu,perc_t,lang[22]);break;
case 3:wsprintf(ws_menu,perc_t,lang[23]);break;
}
DrawString(ws_menu,0,seti_y+nimg*90,max_width,max_height,FONT,2,GetPaletteAdrByColorIndex(2),GetPaletteAdrByColorIndex(23));
wsprintf(ws_menu,perc_t,lang[24]);
DrawString(ws_menu,0,seti_y+nimg*120 ,max_width,max_height,FONT,2,GetPaletteAdrByColorIndex(3),GetPaletteAdrByColorIndex(23));
switch(mode)
{
case 0:wsprintf(ws_menu,perc_t,lang[25]);break;
case 1:wsprintf(ws_menu,"<  %d  >",lives);break;
}
DrawString(ws_menu,0,seti_y+nimg*150,max_width,max_height,FONT,2,GetPaletteAdrByColorIndex(2),GetPaletteAdrByColorIndex(23));
}
break;
case music:
{
DrwImg(pics[3],cur_x,cur_ym);
wsprintf(ws_menu,perc_t,lang[28]);
DrawString(ws_menu,0,music_y,max_width,max_width,FONT,2,GetPaletteAdrByColorIndex(3),GetPaletteAdrByColorIndex(23));
switch(on_off_sound)
{
case 0:wsprintf(ws_menu,perc_t,lang[29]);break;
case 1:wsprintf(ws_menu,perc_t,lang[31]);break;
case 2:wsprintf(ws_menu,perc_t,lang[32]);break;
}
DrawString(ws_menu,0,music_y+nimg*40,max_width,max_width,FONT,2,GetPaletteAdrByColorIndex(2),GetPaletteAdrByColorIndex(23));
wsprintf(ws_menu,"<  %d  >",def_vol);
DrawString(ws_menu,0,music_y+nimg*80,max_width,max_height,FONT,2,GetPaletteAdrByColorIndex(2),GetPaletteAdrByColorIndex(23));
wsprintf(ws_menu,perc_t,lang[34]);
DrawString(ws_menu,0,music_y+nimg*120,max_width,max_width,FONT,2,GetPaletteAdrByColorIndex(3),GetPaletteAdrByColorIndex(23));
switch(vibra)
{
case 0:wsprintf(ws_menu,perc_t,lang[29]);break;
case 1:wsprintf(ws_menu,perc_t,lang[30]);break;
}
DrawString(ws_menu,0,music_y+nimg*160,max_width,max_width,FONT,2,GetPaletteAdrByColorIndex(2),GetPaletteAdrByColorIndex(23));
}
break;
case rec:
{
wsprintf(ws_menu,perc_t,lang[35]);
DrawString(ws_menu,0,nimg*17,max_width,max_height,FONT,2,GetPaletteAdrByColorIndex(2),GetPaletteAdrByColorIndex(23));
for(int i=0;i<NUM_RECORD;i++)
{
wsprintf(ws_menu,"%d.  %s  %d",i+1,record.name[i],record.points[i]);
DrawString(ws_menu,nimg*35,nimg*37+i*(30),nimg*35+Get_WS_width(ws_menu,FONT),nimg*37+i*(30)+GetFontYSIZE(FONT),FONT,2,GetPaletteAdrByColorIndex(3),GetPaletteAdrByColorIndex(23));
}
}
break;
}
FreeWS(ws_menu);
}
void load_lang()
{
WSHDR *ws_menu = AllocWS(64);
DrawRoundedFrame(0,0,max_width,max_height,0,0,0,NULL,bgcol);
DrawRoundedFrame(cur_x,lang_y,nimg*210,lang_y+nimg*30,0,0,0,NULL,bgcol_lang_cur);
switch(langenru)
{
case 0:wsprintf(ws_menu,perc_t,LGP_MENU_LANG1);break;
case 1:wsprintf(ws_menu,perc_t,LGP_MENU_LANG2);break;
}
DrawString(ws_menu,0,max_height/4 ,max_width,max_height,FONT,2,GetPaletteAdrByColorIndex(2),GetPaletteAdrByColorIndex(23)); 
wsprintf(ws_menu,perc_t,LGP_LANG_RU);
DrawString(ws_menu,0,max_height/4+nimg*40,max_width,max_height,FONT,2,GetPaletteAdrByColorIndex(2),GetPaletteAdrByColorIndex(23)); 
wsprintf(ws_menu,perc_t,LGP_LANG_EN);
DrawString(ws_menu,0,max_height/4+nimg*80,max_width,max_height,FONT,2,GetPaletteAdrByColorIndex(2),GetPaletteAdrByColorIndex(23));
FreeWS(ws_menu);
}






void loading(int flag)
{
FSTATS fs;
WSHDR *ws_load = AllocWS(64);
WSHDR *ws_load2 = AllocWS(64);
int dlina=nimg*29*flag;
DrawRoundedFrame(0,0,max_width,max_height,0,0,0,NULL,bgcol);
DrawRectangle(3,max_height/3+nimg*80,max_width-3,max_height/3+nimg*92,0,GetPaletteAdrByColorIndex(2),GetPaletteAdrByColorIndex(23));
DrawRectangle(5,max_height/3+nimg*82,nimg*32+dlina,max_height/3+nimg*90,0,GetPaletteAdrByColorIndex(2),GetPaletteAdrByColorIndex(22));
wsprintf(ws_load2,perc_t,lang[0]);
DrawString(ws_load2,0, max_height/5 ,max_width,max_height,FONT,2,GetPaletteAdrByColorIndex(2),GetPaletteAdrByColorIndex(23));
for(int i=1;i<=6;i++)
{
  DRE(nimg*3+i*(30),color_frame[i]);
}
   switch(flag)
   {
   case 0:case 1:case 2: case 3:case 4: case 5:
    {
  if(GetFileStats(images[flag],&fs,0)!=-1)
{
  wsprintf(ws_load,"%s: %t",images[flag],lang[42]); 
  png(flag);
  color_frame[flag+1]=4;
}
else
{
  error_count++;
  color_frame[flag+1]=2;
  wsprintf(ws_load,"%s: %t",images[flag],lang[43]);
}
DrawString(ws_load,0, max_height/3 ,max_width,max_height,FONT,2,GetPaletteAdrByColorIndex(2),GetPaletteAdrByColorIndex(23));
    }
   break;
   case 6:
     {
     if(error_count>0)
      {
      DrawRoundedFrame(0,0,max_width,max_height,0,0,0,NULL,bgcol);
      WSHDR *ws_err = AllocWS(128);
      wsprintf(ws_err,perc_t,lang[44]); 
      DrawString(ws_err,0, nimg*120 ,max_width,max_height,FONT,2,GetPaletteAdrByColorIndex(2),GetPaletteAdrByColorIndex(23));
      FreeWS(ws_err);
      }
     else
     {
      WSHDR *ws_err = AllocWS(128);
      wsprintf(ws_err,perc_t,lang[45]); 
      DrawString(ws_err,0, nimg*120 ,max_width,max_height,FONT,2,GetPaletteAdrByColorIndex(2),GetPaletteAdrByColorIndex(23));
      FreeWS(ws_err);
     }
     GetSize();
   }
   break;
   case 7:
     {
     if(error_count>0)
      {
      DrawRoundedFrame(0,0,max_width,max_height,0,0,0,NULL,bgcol);
      WSHDR *ws_err = AllocWS(128);
      wsprintf(ws_err,"%t%s%s",lang[46],folder,"img\\"); 
      DrawString(ws_err,0, nimg*30 ,max_width,max_height,FONT,2,GetPaletteAdrByColorIndex(2),GetPaletteAdrByColorIndex(23));
      FreeWS(ws_err);
      }
     else
     {
      status=menu;
      RedrawScreen();
     }
    
   }
    break;
   }


FreeWS(ws_load);
FreeWS(ws_load2);
}
