//������� ������� ��� ��������������
void left_but()
{
  if(status==game)
  {
    if (user.x!=1)user.dx=1;
    else user.dx=0;
  }
  else
  {
  switch(status)
  {
    case menu:
    if(cur_y==nimg*52){if(game_new_cont==3)game_new_cont=2;}else
    if(cur_y==nimg*92){if(saveload==1)saveload=2;}else
    if(cur_y==nimg*132){if(mode==1)mode=0;lives=0;game_new_cont=1;}
    RedrawScreen();
    break;
    case settings_igra:
      if(cur_ys==nimg*72)
      {
    switch(diff)
      {
    case 1:diff=0;break;
    case 2:diff=1;break;
      }
      }
      else
    if(cur_ys==nimg*132)
    {
    switch(speed_game)
      {
      case 1:speed_game=0;break;
      case 2:speed_game=1;break;
      case 3:speed_game=2;break;
      }
    }
    else
      if(cur_ys==nimg*192){if(mode==1)lives--;if (lives<1)lives=99;
    }
       game_new_cont=1;
       if(mode==0)savedata(1);
    RedrawScreen();
   break;
   case music:
       if(cur_ym==nimg*92){if(on_off_sound==1){on_off_sound=0;}else{if(on_off_sound==2){on_off_sound=1;}}}
       if(cur_ym==nimg*212){if(vibra==1){vibra=0;}}
       if(cur_ym==nimg*132){def_vol--;if (def_vol<0)def_vol=6;}
    RedrawScreen();
    break;
   }
  }
}
void right_but()
{
  if(status==game)
  {
     if (user.x!=max_width-user.width-1){user.dx=2;}
       else {user.dx=0;}
  }
  else
  {
  switch(status)
  {
        case menu:
       if (cur_y==nimg*52){if(game_new_cont==2){game_new_cont=3;}}
       if (cur_y==nimg*92){ if(saveload==2){saveload=1; }}
       if (cur_y==nimg*132){if(mode==0){savedata(1);mode=1;lives=7;game_new_cont=1;}}
       RedrawScreen();
     break;
  case settings_igra:
       if (cur_ys==nimg*72){ if(diff==1){diff=2; } if(diff==0){diff=1;}}
       if (cur_ys==nimg*132){ if(speed_game==2){speed_game=3;} if(speed_game==1){speed_game=2;} if(speed_game==0){speed_game=1;}   }
       if (cur_ys==nimg*192&mode==1) { lives++; if (lives>99)lives=1;}
       game_new_cont=1;
       if(mode==0)savedata(1);
       RedrawScreen();
     break;
  case music:
      if (cur_ym==nimg*92){if(on_off_sound==1){on_off_sound=2;} if(on_off_sound==0){on_off_sound=1;}}
      if (cur_ym==nimg*212){if(vibra==0){vibra=1;}}
      if (cur_ym==nimg*132) { def_vol++; if (def_vol>6)def_vol=0;}
      RedrawScreen();
     break;
  }
  }
}
void up_but()
{
  switch(status)
  {
  case load:
    if(isload)
    {
        lang_y=lang_y-nimg*40; if (lang_y<nimg*112){lang_y=nimg*152;}
        if(lang_y==nimg*112){langenru=0;}
        if(lang_y==nimg*152){langenru=1;}
        load_lang();
    }
    break;
  case menu:
        cur_y=cur_y-nimg*40; if (cur_y<nimg*52){cur_y=nimg*252;}
        RedrawScreen();
    break;
  case settings:
        cur_ys1=cur_ys1-nimg*60; if (cur_ys1<nimg*72){cur_ys1=nimg*132;}
        RedrawScreen();
    break;
  case settings_igra:
        cur_ys=cur_ys-nimg*60; if (cur_ys<nimg*72){cur_ys=nimg*192;}
        if (cur_ys==nimg*192&mode==0){cur_ys=nimg*132;}
        RedrawScreen();
    break;
  case music:
       cur_ym=cur_ym-nimg*40; if (cur_ym<nimg*92){cur_ym=nimg*212;}
       if(cur_ym==172)cur_ym=132;
       RedrawScreen();
       break;
  }
}
void down_but()
{
    switch(status)
  {
    case load:
        if(isload==1)
    {
        lang_y=lang_y+nimg*40; if (lang_y>nimg*152){lang_y=nimg*112;}
        if(lang_y==nimg*112){langenru=0;}
        if(lang_y==nimg*152){langenru=1;}
        load_lang();
     }
     break;
    case menu:
        cur_y=cur_y+nimg*40; if (cur_y>nimg*252){cur_y=nimg*52;}
        RedrawScreen();
        break;
      case settings:
        cur_ys1=cur_ys1+nimg*60; if(cur_ys1>nimg*132){cur_ys1=nimg*72;}
        RedrawScreen();
        break;
  case settings_igra:
        cur_ys=cur_ys+nimg*60; if(cur_ys>nimg*192){cur_ys=nimg*72;}
        if (cur_ys==nimg*192&mode==0){cur_ys=72;}
        RedrawScreen();
    break;
    case music:
         cur_ym=cur_ym+nimg*40; if (cur_ym>nimg*212){cur_ym=nimg*92;}
         if(cur_ym==172)cur_ym=212;
         RedrawScreen();
    break;
  }
}
void test()
{
  ShowMSG(1,(int)"bla-bla");
}
void enter_but()
{
  switch(status)
  {
  case load:
          if(isload==1)
   {
         lgpInitLangPack();
         savedata(2);
         isload=0;
         T_Load_IMG();
   }
     break;
  case menu:
        if(cur_y==nimg*52){startcont();}
        if (cur_y==nimg*252)exit();
        if (cur_y==nimg*92){if (saveload==1){saveSettings();}else if (saveload==2){loadSettings();game_new_cont=3;}}
        if (cur_y==nimg*172){status=rec;}
        if(cur_y==nimg*212){status=settings;}
        RedrawScreen();
    break;
  case settings:
      if(cur_ys1==nimg*72){status=settings_igra;}   
      if(cur_ys1==nimg*132){status=music;}
      RedrawScreen();
    break;
  }
}
void left_soft()
{
        if (status==game)
       {
        running=0;
        PlayMelody_PausePlayback(PLAY_ID);
        if(IsTimerProc(&tmr))GBS_StopTimer(&tmr);
        status=menu;
        game_new_cont=3;
        RedrawScreen();
       }
}
void right_soft()
{

  switch(status)
  {
  case settings:
       status=menu; 
       RedrawScreen();
    break;
  case settings_igra:
       status=settings;
       cur_ys=nimg*72;
       RedrawScreen();
    break;
  case music:
      status=settings;
      RedrawScreen();
     break;
  case rec:
          status=menu;
          RedrawScreen();
         break;
  }
}
void green_but()
{
  switch(status)
  {
  case game:
           if (running==1)Time.min=Time.hour=Time.sec=Time.mymsec=0;setgame(1); 
        break;
  case rec:
          savedata(0);
          RedrawScreen();
        break;
   }
}

void resh_but()
{
  if(status==game)
  {
   openconf();
   running=0;
  }
}
