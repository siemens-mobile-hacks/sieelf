#include "..\inc\swilib.h"
#include "../inc/cfg_items.h"
#include "conf_loader.h"

#define UPDATE_TIME (1*262)
#define ELF_ID 0x1EF

CSM_DESC icsmd;
WSHDR *ws;


extern const unsigned int X1;
extern const unsigned int Y1;
extern const unsigned int X2;
extern const unsigned int Y2;
extern const int REM_DAYS;
extern const int REM_MONTH;
extern const int FONT;
extern const char cl[];
extern const char cl2[];
extern const char BEFORE[32];
extern const int ACT_LATER;
char *LATER[3]={"����","���","����"};
extern void InitConfig();

int (*old_icsm_onMessage)(CSM_RAM*,GBS_MSG*);

GBSTMR mytmr;
const char per_t[]="%t";
const char per_td[]="%t %d";
const char per_tdt[]="%t %d %t";
const int DMonth[]={31,28,31,30,31,30,31,31,30,31,30,31};//���-�� ���� � ������
void DrawStr(void *canv,WSHDR *ws)
{   int tmp=0,tmp_d=0;
    int size=GetFontYSIZE(FONT);
    int i;
    TDate date;
    TTime time; 
    GetDateTime(&date,&time);
  
    if(REM_MONTH>date.month)
    {int mon=REM_MONTH - date.month;
      if(mon <=1) tmp=(DMonth[date.month]-date.day) + REM_DAYS + 1;
      else 
      { tmp=(DMonth[date.month]-date.day) + REM_DAYS + 1;
        for(int k=1;k<mon;k++)
                  tmp+=DMonth[date.month+k];
//        tmp+= REM_DAYS + 1;
       // tmp-=date.day ;
                  
      }
    }
    else 
   { tmp=date.day;
    while(tmp<REM_DAYS){tmp_d++;tmp++;}
    tmp=tmp_d;
  }
  if(tmp==1)i=0;
  else if(tmp>=2 && tmp<=4)i=1;
  else i=2;
  if(ACT_LATER)wsprintf(ws,"%t %d %t",BEFORE,tmp,LATER[i]); 
  else wsprintf(ws,per_td,BEFORE,tmp); 
  DrawCanvas(canv,X1,Y1,X2,Y1+size,1);
  DrawString(ws,X1,Y1,X2,Y1+size,7,32,cl,cl2);
  GBS_StartTimerProc(&mytmr,216*300,DrawStr);
  FreeWS(ws);
  return;
}

//==========================
//     ��������������
//==========================

volatile int callhide_mode=0;

#pragma inline=forced
int toupper(int c)
{
  if ((c>='a')&&(c<='z')) c+='A'-'a';
  return(c);
}

int strcmp_nocase(const char *s1,const char *s2)
{
  int i;
  int c;
  while(!(i=(c=toupper(*s1++))-toupper(*s2++))) if (!c) break;
  return(i);
}
/*
int IsIdleUiOnTop(void){ 
void *icsm=FindCSMbyID(CSM_root()->idle_id); 
if (IsGuiOnTop(((int*)icsm)[DISPLACE_OF_IDLEGUI_ID/4 ])) 
return(1); 
else return(0); 
} 
*/
int MyIDLECSM_onMessage(CSM_RAM* data,GBS_MSG* msg)
{
  int csm_result;
  
#define idlegui_id (((int *)data)[DISPLACE_OF_IDLEGUI_ID/4])
     if (msg->msg!=ELF_ID)  csm_result=old_icsm_onMessage(data,msg);
  
  if (msg->msg==MSG_RECONFIGURE_REQ)
  {
      ShowMSG(1,(int)"Config updated!");
      InitConfig();
     }


  if (IsGuiOnTop(idlegui_id)) //���� IdleGui �� ����� �����
  {
    GUI *igui=GetTopGUI();
    if (igui) //� �� ����������
    {
      void *idata;
      idata=GetDataOfItemByID(igui,2);
      if (idata)
      {	void *canvasdata=((void **)idata)[DISPLACE_OF_IDLECANVAS/4];
        ws=AllocWS(256);
        DrawStr(canvasdata,ws);
       }
    }
  }
  
  return(csm_result);
}

// ----------------------------------------------------------------------------

int main()
{
  InitConfig();
  LockSched();
  CSM_RAM *icsm=FindCSMbyID(CSM_root()->idle_id);
  memcpy(&icsmd,icsm->constr,sizeof(icsmd));
  old_icsm_onMessage=icsmd.onMessage;
  icsmd.onMessage=MyIDLECSM_onMessage;
  icsm->constr=&icsmd;
 UnlockSched();
  return 0;
}
