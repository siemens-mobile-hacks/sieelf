#include "..\inc\swilib.h"
#include "conf_loader.h"
#define MIN_UPTIME 1
#define MAX(a,b) (a)>(b)?(a):(b)

GBSTMR timer;

void StartWorkTimer();
void InitSettings();
void Refresh();

extern const int ENA_HELLO_MSG;
extern const unsigned int cfgUpTime;
const int minus11=-11;
unsigned int uiUpdateTime;
int m0=0,m1=0,m2=0,m3=0,m4=0,m5=0,m6=0,m7=0;
int Play=0;

extern const int Profile0,Profile1,
Profile2,Profile3,Profile4,Profile5,
Profile6,Profile7;

typedef struct
{CSM_RAM csm;
}MAIN_CSM;

CSM_RAM *under_idle;

extern void kill_data(void *p, void (*func_p)(void *));

#pragma inline=forced

int toupper(int c)
{if ((c>='a')&&(c<='z')) c+='A'-'a';
 return(c);
}

int strcmp_nocase(const char *s1,const char *s2)
{int i,c;
 while(!(i=(c=toupper(*s1++))-toupper(*s2++))) if (!c) break;
 return(i);
}

int maincsm_onmessage(CSM_RAM* data,GBS_MSG* msg)
{if(msg->msg == MSG_RECONFIGURE_REQ) 
  {extern const char *successed_config_filename;
    if(strcmp_nocase(successed_config_filename,(char *)msg->data0)==0)
    {ShowMSG(1,(int)"Mute controller config updated!");
     InitConfig();
    }} return (1);  
}

static void maincsm_oncreate(CSM_RAM *data)
{
}

static void Killer(void)
{extern void *ELF_BEGIN;
 GBS_DelTimer(&timer);
 kill_data(&ELF_BEGIN,(void (*)(void *))mfree_adr());
}

static void maincsm_onclose(CSM_RAM *csm)
{SUBPROC((void *)Killer);
}

static unsigned short maincsm_name_body[140];

static const struct
{CSM_DESC maincsm;
 WSHDR maincsm_name;
}MAINCSM =
{{maincsm_onmessage,
  maincsm_oncreate,
#ifdef NEWSGOLD
  0,0,0,0,
#endif
  maincsm_onclose,
  sizeof(MAIN_CSM),
  1,&minus11},
 {maincsm_name_body,
  NAMECSM_MAGIC1,
  NAMECSM_MAGIC2,0x0,139
}};

static void UpdateCSMname(void)
{wsprintf((WSHDR*)(&MAINCSM.maincsm_name),"Mute controller v1.4 - (c)SimaFish");
}

void Refresh()
{if(IsPlayerOn()&&Play==0)
 {Play=1;
 }  
 else if(!IsPlayerOn()&&Play==1)
 {Play=0;  
  DoIDLE();
 } 
 else if(IsIdleUiOnTop()) DoIDLE();
 REDRAW();
}

void StartWorkTimer()
{int *Ring=(int*)RamRingtoneStatus();
  
 if(GetProfile()==0) 
 {if(Profile0&&*Ring==0) if(m0==0)
  {*RamRingtoneStatus()=1;
   Refresh();
  }
  if(!Profile0&&*Ring==1) if(m0==0)
  {*RamRingtoneStatus()=0;
   Refresh();
  }
   m1=m2=m3=m4=m5=m6=m7=0;
   m0=1;}
 
 if(GetProfile()==1) 
 {if(Profile1&&*Ring==0) if(m1==0)
  {*RamRingtoneStatus()=1;
   Refresh();
  }
  if(!Profile1&&*Ring==1) if(m1==0)
  {*RamRingtoneStatus()=0;
   Refresh();
  }
   m0=m2=m3=m4=m5=m6=m7=0;
   m1=1;}
 
 if(GetProfile()==2) 
 {if(Profile2&&*Ring==0) if(m2==0)
  {*RamRingtoneStatus()=1;
   Refresh();
  }
  if(!Profile2&&*Ring==1) if(m2==0)
  {*RamRingtoneStatus()=0;
   Refresh();
  }
   m0=m1=m3=m4=m5=m6=m7=0;
   m2=1;}
 
 if(GetProfile()==3) 
 {if(Profile3&&*Ring==0) if(m3==0)
  {*RamRingtoneStatus()=1;
   Refresh();
  }
  if(!Profile3&&*Ring==1) if(m3==0)
  {*RamRingtoneStatus()=0;
   Refresh();
  }
   m0=m1=m2=m4=m5=m6=m7=0;
   m3=1;}
 
 if(GetProfile()==4) 
 {if(Profile4&&*Ring==0) if(m4==0)
  {*RamRingtoneStatus()=1;
   Refresh();
  }
  if(!Profile4&&*Ring==1) if(m4==0)
  {*RamRingtoneStatus()=0;
   Refresh();
  }
   m0=m1=m2=m3=m5=m6=m7=0;
   m4=1;}
 
 if(GetProfile()==5) 
 {if(Profile5&&*Ring==0) if(m5==0)
  {*RamRingtoneStatus()=1;
   Refresh();
  }
  if(!Profile5&&*Ring==1) if(m5==0)
  {*RamRingtoneStatus()=0;
   Refresh();
  }
   m0=m1=m2=m3=m4=m6=m7=0;
   m5=1;}
 
 if(GetProfile()==6) 
 {if(Profile6&&*Ring==0) if(m6==0)
  {*RamRingtoneStatus()=1;
   Refresh();
  }
  if(!Profile6&&*Ring==1) if(m6==0)
  {*RamRingtoneStatus()=0;
   Refresh();
  }
   m0=m1=m2=m3=m4=m5=m7=0;
   m6=1;}
 
 if(GetProfile()==7) 
 {if(Profile7&&*Ring==0) if(m7==0)
  {*RamRingtoneStatus()=1;
   Refresh();
  }
  if(!Profile7&&*Ring==1) if(m7==0)
  {*RamRingtoneStatus()=0;
   Refresh();
  }
   m0=m1=m2=m3=m4=m5=m6=0;
   m7=1;}

 GBS_StartTimerProc(&timer, uiUpdateTime, StartWorkTimer);
}

void InitSettings()
{InitConfig();
 uiUpdateTime = MAX(((216*cfgUpTime)/10),MIN_UPTIME);
 StartWorkTimer();
}

void main()
{ CSM_RAM *save_cmpc;
  char dummy[sizeof(MAIN_CSM)];
  UpdateCSMname(); 
  LockSched();
  save_cmpc=CSM_root()->csm_q->current_msg_processing_csm;
  CSM_root()->csm_q->current_msg_processing_csm=CSM_root()->csm_q->csm.first;
  CreateCSM(&MAINCSM.maincsm,dummy,0);
  CSM_root()->csm_q->current_msg_processing_csm=save_cmpc;  
  UnlockSched();
  InitSettings();
}

