#include "..\inc\cfg_items.h"

__root const CFG_HDR cfghdr0={CFG_UINT, "Refresh rate (1/10 sec):", 0, 50};
__root const unsigned int cfgUpTime=3;

__root const CFG_HDR cfghdr1={CFG_CHECKBOX,"Profile1",0,2};
__root const int Profile0=0;

__root const CFG_HDR cfghdr2={CFG_CHECKBOX,"Profile2",0,2};
__root const int Profile1=0;

__root const CFG_HDR cfghdr3={CFG_CHECKBOX,"Profile3",0,2};
__root const int Profile2=0;

__root const CFG_HDR cfghdr4={CFG_CHECKBOX,"Profile4",0,2};
__root const int Profile3=0;

__root const CFG_HDR cfghdr5={CFG_CHECKBOX,"Profile5",0,2};
__root const int Profile4=0;

__root const CFG_HDR cfghdr6={CFG_CHECKBOX,"Profile6",0,2};
__root const int Profile5=0;

__root const CFG_HDR cfghdr7={CFG_CHECKBOX,"Profile7",0,2};
__root const int Profile6=0;

__root const CFG_HDR cfghdr8={CFG_CHECKBOX,"Profile8",0,2};
__root const int Profile7=0;




